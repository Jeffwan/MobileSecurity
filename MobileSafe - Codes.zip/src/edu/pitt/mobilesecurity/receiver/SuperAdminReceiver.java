package edu.pitt.mobilesecurity.receiver;

import android.app.admin.DeviceAdminReceiver;

public class SuperAdminReceiver extends DeviceAdminReceiver {

	// Nothing here, but receiver configuration in Manifest and operation in xml
	
}
